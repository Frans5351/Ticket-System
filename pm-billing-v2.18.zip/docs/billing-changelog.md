# Billing changelog

## v2.18 — the unit lookup shows the photo whenever one is on file
- **Fix:** when a house had two readings on the same day — one typed on the Billing meters tab and one that came with a photo — the residents' lookup showed the Billing one, which has no photo. It now ranks the same way as the Water readings list: by the reading's date, and on the same day the one that arrived with a photo first.
- If the newest reading was typed in without a photo, the lookup shows the most recent photo on file for that month beside it, captioned with the photo's date.

## v2.17 — "the managing agent has this reading" can be set by hand
- Each reading in Water readings now has an **Agent** line: *emailed by the app*, *sent outside the app · marked by <name>*, or *not sent yet*.
- Edit a reading (the latest or any earlier one) and tick **The managing agent has this reading** if it was sent to them another way, e.g. by email or WhatsApp. Untick to undo. Readings the app emailed itself are shown ticked and locked.
- New readings captured by hand can be ticked the same way when they are added.

## v2.16 — Water readings list shows the newest reading, and all of them
- **Fix:** a house's entry is now chosen by the reading's own date. Before, a reading typed on the Billing meters tab (e.g. dated the 8th) could sit on top of a photo the resident sent later, because Billing readings were time-stamped when they were copied into the list rather than when they were taken. On the same day, a reading sent with a photo ranks above the Billing copy.
- **Every reading of the month is shown** under the house ("Also this month"), each with its date, reading, how it arrived, photo thumbnails and Drive link — not just a count. Any of them can be edited or removed (Billing-tab readings are changed in Billing).
- **Fresh every time:** opening Water readings always reloads from the database, so readings that came in while the app was open appear without pressing ↻.

## v2.15 — residents can get a copy of their water reading by email
- Water reading form (`?water` and the Water Reading tile): new optional step 4, **Email me a copy**. If an address is filled in, the resident is emailed their reading as a record — unit, date and time received, what they typed, and the photo attached. The address is remembered on that device.
- The copy is a separate email (`functions/send-edit-link.js`), not a CC, so the managing agent's addresses aren't shown to the resident. Replies to it go to the Park Manor inbox. The agent's email still names the resident's address and replies from the agent go straight to them.
- Test mode (email box unticked): the managing agent and Park Manor inbox are skipped as before, but a copy still goes to the address typed, so the copy can be tested on its own.
- The page says whether the copy went out; the register shows "Copy: emailed to …" on the reading. A copy that can't be delivered never blocks the reading itself.

## v2.14 — photos dropped into Drive are picked up; status panel uses only the readings table
- **Photos added straight into the Drive folder.** Water readings checks `Park Manor Water Meter Readings / <Month Year>` each time it is opened (and on ↻). Photos it doesn't know yet are listed with **Add them to the list**: the house comes from the file name (`Unit 3.jpg`), the date from when the file was added, the meter is read from the photo for confirmation, and the Drive file is linked (nothing is uploaded twice). Files with other names can be assigned to a house or skipped. Needs version 3 of the Google script (`docs/water-readings-drive.gs`: paste, put the password back, Deploy → Manage deployments → New version).
- **Residents' status panel** ("when did you last get my reading?") now reads only the `water_readings` table. Old tick marks kept in settings — some copied from Davies invoice dates such as 1 November — are no longer shown.
- **Register clean-up** (once, on opening): ticks copied from the Billing meters tab before the table existed are dropped (genuine Billing readings are re-derived), and ticks made by hand become proper readings.
- "Save to Drive & read" on a reading that is already in Drive only reads the photo; it no longer uploads a second copy.
- Server: `/api/water-reading` gains `driveList` / `driveGet` (trustees, admin and managing agent only — checked against the signed-in session when `PASSKEY_JWT_SECRET` is configured). The script only serves files inside the water readings folder.

## v2.13 — date and time in the Drive file name
- Water-meter photos are filed as `Unit N - 16 Nov 2026 21h35.jpg` (when the reading reached the app, South African time) instead of plain `Unit N.jpg`. Needs a one-line change in the Google script plus a New version of its deployment; until then files keep the old name and nothing breaks.
- `WATER_READINGS_SETUP.sql` now also switches row-level security off on `water_readings` and grants the app access, matching the other tables (the cause of "test reading could not be saved").

## v2.12 — test a water reading without emailing anyone
- Water reading form (`?water` and the Water Reading tile): a tick box **Email this reading to the managing agent**, ticked by default. Untick it and nothing is emailed; the reading is still saved, the photo filed in Google Drive and the meter read from it. The register marks such a reading "test, not emailed".
- The box only appears when someone is signed in to the app on that device, or the link ends in `&test` (e.g. `…/?water&test`). Residents never see it, so their readings are always emailed.
- After a test send the page shows exactly what happened: saved or not, the Drive file (or why it wasn't filed), and what the photo was read as (or why not).
- Zip carries complete folders (as from v2.11).

## v2.11 — repair: complete folders
- No app changes. The v2.10 zip carried only the changed files, and replacing the `functions/` folder with it in Finder removed the other 17 server functions, so the Netlify build failed (`Could not resolve "./_passkey-shared.js"`). This zip carries the **complete** `functions/`, `public/` and `docs/` folders, so replacing those folders is safe. It also restores `public/park-manor-entrance.jpg`, `public/deploy.txt` and the architecture docs that went missing the same way.
- From now on every zip contains complete folders.

## v2.10 — residents see the photo on file
- Water form status panel: the photo that goes with the reading shown (this month, else the last one) appears beside the date and reading; tap to enlarge. Served from the copy in the database (Drive files are private).


## v2.9 — water photos to Google Drive; meter read from the photo
- New server function `functions/water-reading.js` + Apps Script `docs/water-readings-drive.gs`: every water-meter photo (from the forms or attached in the register) is filed as `Park Manor Water Meter Readings / <Month Year> / Unit N.jpg`, and Claude reads the meter from the first photo. Setup in `docs/WATER_PHOTOS_SETUP.md` (three Netlify env vars).
- Register: Drive link per reading; "The photo reads X (confidence)" suggestion with **Use**; a flag when the typed reading and the photo disagree; **Save to Drive & read** for older entries; chips showing whether each feature is on.
- Public form: after sending, the resident sees that the photo was filed and what the meter was read as (to be confirmed).


## v2.8 — imported invoice readings never count; Water readings in the sidebar
- Meter rows that came in with a Davies invoice (dated by the invoice, e.g. 1 November) are recognised even without an invoice number on the row — by matching the reading to the imported invoice — and never count as a reading received. Rows an earlier build wrongly ticked off are removed the next time the register is opened. On the Meters tab they are labelled "Davies invoice · billing date".
- "Water readings" is now an item in the desktop sidebar as well as the burger menu (admin, trustees, management).


## v2.7 — Billing meter readings count as received
- A water reading saved on a unit’s Meters tab in Billing (or captured on an invoice issued here) now ticks that house off on the Water readings register and shows as received on the resident’s status panel. Readings that arrived with imported Davies invoices do not count. Deleting the reading in Billing takes the tick off again.
- Existing Billing readings are picked up the next time the register is opened.


## v2.6 — residents see when their reading was last received
- Water form (`?water` and the Water Reading tile): typing the unit number shows whether this month has been received and the date/reading of the last one on file, including readings captured by hand in the register. The unit is remembered on the device.
- Form submissions now store every attached photo (shrunk) plus the full message, and are dated in local time.


## v2.5 — capture water readings by hand
- Water meter readings register: **Add reading** per house (or from the footer with a house picker): type the reading, set the date, attach up to 3 photos (camera or gallery), add a note. Stored alongside the form submissions.
- Any entry can be edited (e.g. type in the reading from a photo that came through the form) or removed; the row shows who captured or edited it and the usage since last month.
- Also reachable from the burger menu (Water readings) for admin, trustees and management.
- Readings load one month at a time and stored photos are shrunk, so the screen stays fast.


## v2.4 — water meter readings
- General `?report` form: the **Water Reading** tile now swaps to the water-meter form (unit, photo, reading, note) with a way back; same routing as `?water` (managing agent + Park Manor inbox, not trustees).
- Both forms now also save the submission (unit, month, reading, note, up to 2 photos) to a new `water_readings` table — run `WATER_READINGS_SETUP.sql` once in Supabase.
- New **Water meter readings** register (Tracker header 💧 Readings for admin/trustees/management; Billing ⋯ menu): per month from Nov 2026, one row per house, ticked automatically from the forms, mark the rest by hand, copy a WhatsApp reminder of who is outstanding, push a reading into billing.


## v2.3 — quotas: load all 20 sections
- Quotas & splits says exactly why the PQs do not total 100 (which sections are missing or blank) and **Load Park Manor figures** fills PQ and fixed-charge ratio for all 20 sections from the Davies/Azure sheet, creating the garage sections if the register only has doors 1–12. Save, and the warning goes.


## v2.2 — shared charges, quotas & splits
- ⋯ → **Shared charges & recoveries**: set up any charge for all houses at once
  (every month / over N months / once), split by participation quota, equally,
  by the fixed-charge ratio, typed per house, or by the CSOS rule; preview per
  house, apply, and every house's Charges tab is updated. Backdated recoveries
  and special levies are "over N months" plans; progress is counted from the
  invoices issued.
- First open offers to adopt the shared lines already learned from the Davies
  invoices (levies, reserve fund, CSOS, garage levy, service charge, fixed basic
  charges, both backdate recoveries, garden service) with amounts kept exactly.
- Billing settings → **Quotas & splits**: edit each section's PQ and fixed-charge
  ratio (from the Davies/Azure sheet of 29 Oct 2026; totals checked), and the
  default bases: levies by PQ, municipal fixed charges by the ratio.

## v2.1 — instalments counted from the invoices on file
## v2 — invoicing engine (see billing.md)
